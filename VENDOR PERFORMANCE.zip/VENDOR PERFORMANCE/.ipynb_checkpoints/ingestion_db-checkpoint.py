import os
import time
import logging
import pandas as pd
from sqlalchemy import create_engine

# --- Setup logging (both file + console) ---
log_file = "logs/ingestion_db.log"
os.makedirs(os.path.dirname(log_file), exist_ok=True)

logging.basicConfig(
    filename=log_file,
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
    filemode="a"
)

# Console handler
console = logging.StreamHandler()
console.setLevel(logging.INFO)  # DEBUG shows even more
formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
console.setFormatter(formatter)
logging.getLogger().addHandler(console)

# --- DB Connection ---
engine = create_engine("sqlite:///inventory.db")

# --- Safe ingestion with chunking ---
def ingest_db(df, table_name, engine):
    num_cols = len(df.columns)
    max_vars = 30000  # SQLite limit ~32766
    max_rows = max_vars // num_cols
    chunksize = min(len(df), max_rows, 50000)  # hard cap 50k rows per insert

    total_inserted = 0
    first = True

    for i in range(0, len(df), chunksize):
        chunk = df.iloc[i:i + chunksize]
        chunk.to_sql(
            table_name,
            con=engine,
            if_exists="replace" if first else "append",
            index=False,
            chunksize=chunksize,
            method="multi"
        )
        total_inserted += len(chunk)
        first = False
        logging.debug(f"Inserted {len(chunk)} rows into '{table_name}'")

    logging.info(f"Inserted total {total_inserted} rows into table '{table_name}'")

# --- Main Loader ---
def load_raw_data():
    start = time.time()
    logging.info("🚀 Starting data ingestion process...")

    for file in os.listdir("data"):
        if file.endswith(".csv"):
            try:
                logging.debug(f"Reading file: {file}")
                df = pd.read_csv(os.path.join("data", file))
                logging.info(f"Read {file} successfully → shape: {df.shape}")

                table_name = file[:-4]
                logging.info(f"Ingesting {file} into DB as table '{table_name}'...")
                ingest_db(df, table_name, engine)
                logging.info(f"✅ Finished ingesting {file}")

            except Exception as e:
                logging.error(f"❌ Error processing {file}: {e}", exc_info=True)

    end = time.time()
    total_time = (end - start) / 60
    logging.info("🎯 Ingestion Complete")
    logging.info(f"⏱ Total Time Taken: {total_time:.2f} minutes")


# --- Run ---
if __name__ == "__main__":
    load_raw_data()
